const express = require("express");
const router = express.Router();
const { getContainer } = require("../config/cosmos");
const fs = require("fs");

// 首頁(問卷頁面)
router.get("/", (req, res) => {
  res.render("index");
});

router.post("/submit", async (req, res) => {
  try {
    const container = await getContainer();
    const surveyData = req.body;

    // Insert a date/time of submission
    surveyData.createdAt = new Date().toISOString();

    // Write to DB
    const { resource: createdItem } = await container.items.create(surveyData);
    res.render("thankyou", { surveyId: createdItem.id });
  } catch (error) {
    console.error("Error saving survey:", error);
    res.status(500).send("Server error");
  }
});

router.post("/load-json", async (req, res) => {
  try {
    // 4a) Read your local JSON file
    //     (Assuming questions.json is in the same directory or adjust path as needed)
    const filePath =
      "/Users/waiwai/Desktop/VScode/OnlineSurveySystem/data/mockData.json";
    const jsonData = JSON.parse(fs.readFileSync(filePath, "utf8"));

    // 4b) Get your Cosmos DB container reference
    const container = await getContainer();

    // 4c) For each record in the JSON array, insert into Cosmos DB
    for (const item of jsonData) {
      // If there's no property 'id', generate one
      if (!item.id) {
        item.id = `${Date.now()}-${Math.random()}`;
      }

      // Insert the item
      const { resource: newItem } = await container.items.create(item);
      console.log("Inserted item with id:", newItem.id);
    }

    res.json({
      status: "success",
      message: "JSON file loaded into Cosmos DB successfully",
    });
  } catch (error) {
    console.error("Error loading JSON into Cosmos:", error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
