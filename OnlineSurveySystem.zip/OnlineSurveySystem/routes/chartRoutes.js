const express = require("express");
const router = express.Router();
const { getContainer } = require("../config/cosmos");

// 長條圖
router.get("/bar", async (req, res) => {
  try {
    const container = await getContainer();
    const { resources: allResponses } = await container.items
      .query("SELECT * FROM c")
      .fetchAll();
    res.render("chartBar", { surveyData: allResponses });
  } catch (error) {
    console.error("Error fetching data for bar chart:", error);
    res.status(500).send("伺服器錯誤，請稍後再試。");
  }
});

// 圓餅圖
router.get("/pie", async (req, res) => {
  try {
    const container = await getContainer();
    const { resources: allResponses } = await container.items
      .query("SELECT * FROM c")
      .fetchAll();
    res.render("chartPie", { surveyData: allResponses });
  } catch (error) {
    console.error("Error fetching data for pie chart:", error);
    res.status(500).send("伺服器錯誤，請稍後再試。");
  }
});

// 折線圖
router.get("/line", async (req, res) => {
  try {
    const container = await getContainer();
    const { resources: allResponses } = await container.items
      .query("SELECT * FROM c")
      .fetchAll();
    res.render("chartLine", { surveyData: allResponses });
  } catch (error) {
    console.error("Error fetching data for line chart:", error);
    res.status(500).send("伺服器錯誤，請稍後再試。");
  }
});

module.exports = router;
