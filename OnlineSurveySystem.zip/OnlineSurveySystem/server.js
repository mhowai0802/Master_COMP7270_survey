require("dotenv").config();
const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");

const surveyRoutes = require("./routes/surveyRoutes");
const chartRoutes = require("./routes/chartRoutes");

const app = express();
const PORT = process.env.PORT || 3000;

// 設定 EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// 靜態檔案
app.use(express.static(path.join(__dirname, "public")));

// 解析 body
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// 路由
app.use("/", surveyRoutes);
app.use("/charts", chartRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
