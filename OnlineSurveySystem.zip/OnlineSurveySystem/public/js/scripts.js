// public/js/scripts.js

document.addEventListener("DOMContentLoaded", function () {
  const favoriteGenreSelect = document.getElementById("favoriteGenre");
  const subGenreSelect = document.getElementById("subGenre");

  // 定義「子類型」對應表
  // key = 主類型, value = 對應的子類型陣列
  const subGenreOptions = {
    action: ["武打", "特技動作", "超級英雄", "諜報"],
    comedy: ["浪漫喜劇", "黑色喜劇", "惡搞喜劇"],
    drama: ["歷史劇情", "愛情劇情", "社會議題"],
    horror: ["靈異鬼片", "血腥暴力", "心理驚悚"],
    "sci-fi": ["太空科幻", "未來世界", "外星人"],
    others: ["紀錄片", "動畫", "音樂劇", "其他"],
  };

  // 每次改變 Q1，就動態更新 Q2
  favoriteGenreSelect.addEventListener("change", function () {
    const selectedGenre = favoriteGenreSelect.value;

    // 先清空子類型
    subGenreSelect.innerHTML = "";

    if (selectedGenre && subGenreOptions[selectedGenre]) {
      // 有對應的子類型
      const options = subGenreOptions[selectedGenre];
      options.forEach((sub) => {
        const opt = document.createElement("option");
        opt.value = sub;
        opt.textContent = sub;
        subGenreSelect.appendChild(opt);
      });
    } else {
      // 如果沒有選擇或沒有對應，就維持空白或給一個「無子類型」
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "無可選子類型";
      subGenreSelect.appendChild(opt);
    }
  });
});
