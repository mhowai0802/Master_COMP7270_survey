require("dotenv").config();
const { CosmosClient } = require("@azure/cosmos");

// 從環境變數抓取連線字串與相關資訊 (此處皆為範例)
const cosmosEndpoint =
  process.env.COSMOS_ENDPOINT ||
  "https://<your-cosmosdb-account>.documents.azure.com:443/";
const cosmosKey = process.env.COSMOS_KEY || "<your-cosmosdb-key>";
const cosmosDatabaseId = process.env.COSMOS_DB_NAME || "SurveyDB";
const cosmosContainerId = process.env.COSMOS_CONTAINER_NAME || "Responses";

// 建立 CosmosClient
const client = new CosmosClient({
  endpoint: cosmosEndpoint,
  key: cosmosKey,
});

// 取得 database 與 container reference (若沒有會自動建立，也可手動建立)
async function getContainer() {
  const { database } = await client.databases.createIfNotExists({
    id: cosmosDatabaseId,
  });
  const { container } = await database.containers.createIfNotExists({
    id: cosmosContainerId,
  });
  return container;
}

module.exports = { getContainer };
